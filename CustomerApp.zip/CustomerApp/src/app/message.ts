import { Customer } from './customer';

export class Message {
    message: string;
    error: string;
    customers: Customer[];
}